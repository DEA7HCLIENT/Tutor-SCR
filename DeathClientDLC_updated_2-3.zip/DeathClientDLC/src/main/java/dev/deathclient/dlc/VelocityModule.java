package dev.deathclient.dlc;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Velocity (anti-knockback): scales the push you get from a server velocity packet.
 * 100% = vanilla, 0% = no knockback. The hook is ClientPlayNetworkHandlerMixin; explosion knockback is not covered.
 */
public class VelocityModule extends Module {
    public final NumberSetting horizontal = add(new NumberSetting("Horizontal %", 0, 0, 100, 5));
    public final NumberSetting vertical = add(new NumberSetting("Vertical %", 0, 0, 100, 5));

    public VelocityModule() { super("Velocity", Category.COMBAT); }

    /** Called right after the client applied a velocity packet that changed the player's motion. */
    public void apply(ClientPlayerEntity p) {
        Vec3d v = p.getVelocity();
        double h = horizontal.get() / 100.0, y = vertical.get() / 100.0;
        p.setVelocity(v.x * h, v.y * y, v.z * h);
    }
}
