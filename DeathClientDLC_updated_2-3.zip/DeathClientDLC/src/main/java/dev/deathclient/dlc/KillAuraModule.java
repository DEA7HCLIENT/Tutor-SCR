package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Kill Aura: automatically attacks every valid target in reach, no clicking and no aiming needed.
 * <ul>
 *   <li>Rotation: None (attack only), Silent (server is told the aim for each hit, your camera never moves),
 *       Smooth (camera eases toward the target), Neuro (camera, human-like: eased speed, random aim point,
 *       mouse-sensitivity grid), VodkaCraft (server-side smoothed rotation on the sensitivity grid, attacks
 *       only once the aim has arrived), HvH (instant server-side lock on the target, held every tick).</li>
 *   <li>Reach is measured to the target's hitbox, the way the server measures it.</li>
 *   <li>Normal mode waits for the weapon cooldown; HvH mode hits every tick.</li>
 * </ul>
 * The VodkaCraft / Neuro profiles are heuristics (smoothing, GCD snapping, aim gating); they have not been
 * checked against any particular server's anti-cheat.
 */
public class KillAuraModule extends Module {
    private static final int NONE = 1, SILENT = 2, SMOOTH = 3, NEURO = 4, VODKA = 5, HVH = 6;

    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));
    public final NumberSetting rotation = add(new NumberSetting("Rotation", 2, 1, 6, 1)
            .labels("None", "Silent", "Smooth", "Neuro", "VodkaCraft", "HvH"));
    /** Max degrees per tick for Smooth / Neuro / VodkaCraft. */
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 18, 4, 60, 1));
    public final BoolSetting hvh = add(new BoolSetting("HvH mode", false));
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.0, 1.0, 0.05));
    public final NumberSetting targets = add(new NumberSetting("Targets", 1, 1, 5, 1));
    /** 1 = nearest first, 2 = lowest health first. */
    public final NumberSetting priority = add(new NumberSetting("Priority", 1, 1, 2, 1));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting inGui = add(new BoolSetting("Attack in GUI", false));

    /** Server-side rotation held by VodkaCraft / HvH while a target exists. */
    private boolean srvActive;
    private float srvYaw, srvPitch;
    /** Neuro: aim point offset inside the hitbox, re-rolled every few ticks. */
    private LivingEntity aimTarget;
    private Vec3d aimOffset = Vec3d.ZERO;
    private int aimTicks;

    public KillAuraModule() { super("KillAura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if ((!inGui.get() && c.currentScreen != null) || !p.isAlive() || p.isSpectator()) {
            release(c, p);
            return;
        }

        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (!invisible.get() && le.isInvisible()) continue;
            if (reach(p, le) <= range.get()) list.add(le);
        }
        if (list.isEmpty()) {
            release(c, p);
            aimTarget = null;
            return;
        }

        if ((int) priority.get() == 2) list.sort(Comparator.comparingDouble(LivingEntity::getHealth));
        else list.sort(Comparator.comparingDouble(e -> reach(p, e)));

        int mode = (int) rotation.get();
        LivingEntity primary = list.get(0);
        if (primary != aimTarget) { aimTarget = primary; aimTicks = 0; }
        if (mode != VODKA && mode != HVH) release(c, p);

        boolean aligned = true;
        switch (mode) {
            case SMOOTH -> turnToward(p, primary);
            case NEURO -> aligned = neuro(c, p, primary);
            case VODKA -> aligned = vodka(c, p, primary);
            case HVH -> hvhLock(c, p, primary);
            default -> {}
        }

        float need = hvh.get() ? 0f : (float) cooldown.get();
        if (!aligned || p.getAttackCooldownProgress(0.5f) < need) return;

        int count = Math.min(list.size(), (int) targets.get());
        if (mode == NEURO || mode == VODKA) count = 1;   // one aim point at a time
        for (int i = 0; i < count; i++) {
            LivingEntity t = list.get(i);
            if (mode == SILENT || (mode == HVH && i > 0)) {
                sendLook(c, p, wantYaw(p, t), wantPitch(p, t));   // server sees the aim for this hit
            }
            c.interactionManager.attackEntity(p, t);
        }
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        if (mode == SILENT) sendLook(c, p, p.getYaw(), p.getPitch());                   // back to the real view
        else if (mode == HVH && count > 1) sendLook(c, p, srvYaw, srvPitch);            // back to the lock
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        release(c, c.player);
        aimTarget = null;
    }

    /** Ends a held server-side rotation by telling the server the real view again. */
    private void release(MinecraftClient c, ClientPlayerEntity p) {
        if (!srvActive) return;
        srvActive = false;
        if (p != null) sendLook(c, p, p.getYaw(), p.getPitch());
    }

    // ---- rotation profiles ----

    /** Camera rotation: speed eases with the remaining angle, aim point wanders inside the hitbox, deltas sit on the mouse grid. */
    private boolean neuro(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (aimTicks-- <= 0) {
            Box b = t.getBoundingBox();
            aimOffset = new Vec3d(r.nextDouble(-0.25, 0.25) * b.getLengthX(),
                    (r.nextDouble(0.55, 0.85) - 0.5) * b.getLengthY(),
                    r.nextDouble(-0.25, 0.25) * b.getLengthZ());
            aimTicks = r.nextInt(5, 11);
        }
        float[] want = Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter().add(aimOffset));
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        float gcd = gcd(c);
        float max = (float) turnSpeed.get();
        p.setYaw(p.getYaw() + snap(humanStep(dy, max, r), gcd));
        p.setPitch(MathHelper.clamp(p.getPitch() + snap(humanStep(dp, max * 0.6f, r), gcd), -90f, 90f));
        return Math.abs(MathHelper.wrapDegrees(want[0] - p.getYaw())) <= 20f && Math.abs(want[1] - p.getPitch()) <= 20f;
    }

    /** Server-side rotation: held between ticks, advanced by a limited, slightly randomized step on the mouse grid. */
    private boolean vodka(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        Box b = t.getBoundingBox();
        Vec3d point = new Vec3d(b.getCenter().x, b.minY + b.getLengthY() * 0.7 + r.nextDouble(-0.03, 0.03), b.getCenter().z);
        float[] want = Util.rotationsTo(p.getEyePos(), point);
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float gcd = gcd(c);
        float max = (float) turnSpeed.get();
        srvYaw += snap(MathHelper.clamp(dy, -max, max) * (float) r.nextDouble(0.85, 1.0), gcd);
        srvPitch = MathHelper.clamp(srvPitch + snap(MathHelper.clamp(dp, -max * 0.5f, max * 0.5f) * (float) r.nextDouble(0.85, 1.0), gcd), -90f, 90f);
        sendLook(c, p, srvYaw, srvPitch);
        return Math.abs(MathHelper.wrapDegrees(want[0] - srvYaw)) <= 12f && Math.abs(want[1] - srvPitch) <= 12f;
    }

    /** Server-side rotation: snaps onto the hitbox center every tick and stays there. */
    private void hvhLock(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        srvActive = true;
        srvYaw = wantYaw(p, t);
        srvPitch = wantPitch(p, t);
        sendLook(c, p, srvYaw, srvPitch);
    }

    /** Fast when far, slow when close, never overshoots. */
    private static float humanStep(float diff, float max, ThreadLocalRandom r) {
        float mag = Math.abs(diff);
        float step = Math.min(max, mag * 0.45f + 0.8f) * (float) r.nextDouble(0.85, 1.15);
        return Math.copySign(Math.min(step, mag), diff);
    }

    /** Smallest rotation the mouse can produce at the current sensitivity (degrees per mouse count). */
    private static float gcd(MinecraftClient c) {
        double f = c.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }

    private static float snap(float delta, float gcd) {
        return Math.round(delta / gcd) * gcd;
    }

    // ---- geometry / packets ----

    /** Distance from the player's eyes to the nearest point of the target's hitbox. */
    private static double reach(ClientPlayerEntity p, Entity e) {
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static float wantYaw(ClientPlayerEntity p, Entity t) {
        return Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter())[0];
    }

    private static float wantPitch(ClientPlayerEntity p, Entity t) {
        return Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter())[1];
    }

    private static void sendLook(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        if (c.getNetworkHandler() == null) return;
        c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, MathHelper.clamp(pitch, -90f, 90f), p.isOnGround(), p.horizontalCollision));
    }

    /** Smooth mode: turns the camera at most turnSpeed degrees this tick, the shorter way around. */
    private void turnToward(ClientPlayerEntity p, LivingEntity target) {
        float step = (float) turnSpeed.get();
        float yawDiff = MathHelper.wrapDegrees(wantYaw(p, target) - p.getYaw());
        float pitchDiff = MathHelper.wrapDegrees(wantPitch(p, target) - p.getPitch());
        p.setYaw(p.getYaw() + MathHelper.clamp(yawDiff, -step, step));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitchDiff, -step, step), -90f, 90f));
    }
}
