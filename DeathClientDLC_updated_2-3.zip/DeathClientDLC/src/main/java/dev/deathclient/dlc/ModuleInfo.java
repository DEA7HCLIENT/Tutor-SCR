package dev.deathclient.dlc;

import java.util.Map;

/** Short descriptions shown on the module cards in the ClickGUI. */
final class ModuleInfo {
    private static final Map<String, String> DESC = Map.ofEntries(
            Map.entry("KillAura", "Автоматически бьёт ближайших существ"),
            Map.entry("TPAura", "Телепортируется к цели для удара"),
            Map.entry("Crystal Aura", "Автоматически ставит и бьёт кристаллы"),
            Map.entry("Anchor Aura", "Ставит и взрывает якорь у врага"),
            Map.entry("Crystal Optimization", "Убирает задержку у кристаллов"),
            Map.entry("Velocity", "Уменьшает отбрасывание от ударов"),
            Map.entry("Speed", "Увеличивает скорость передвижения"),
            Map.entry("Strafe", "Улучшенное управление в воздухе"),
            Map.entry("Target Strafe", "Кружит вокруг цели при атаке"),
            Map.entry("Fly", "Полёт без режима творчества"),
            Map.entry("NoClip", "Проход сквозь блоки"),
            Map.entry("NoClip Fly", "Полёт сквозь стены"),
            Map.entry("Spin", "Вращает персонажа вокруг оси"),
            Map.entry("ESP", "Рамки вокруг игроков и мобов"),
            Map.entry("Glow ESP", "Подсвечивает существ сквозь стены"),
            Map.entry("Block ESP", "Рамки вокруг руд, сундуков и спавнеров"),
            Map.entry("Freecam", "Свободная камера отдельно от игрока"),
            Map.entry("Chams", "Цветная заливка моделей сквозь стены"),
            Map.entry("No Render", "Отключает отрисовку лишнего"),
            Map.entry("View Model", "Положение предмета в руке"),
            Map.entry("Swing Animation", "Своя анимация взмаха руки"),
            Map.entry("Visual Spin", "Вращение модели без смены угла"),
            Map.entry("Tracers", "Линии к игрокам"),
            Map.entry("Line Trails", "Линии-следы за движением"),
            Map.entry("Target ESP", "Эффект при наводке на цель"),
            Map.entry("Target ESP Image", "Картинка-метка на цели"),
            Map.entry("Target ESP Ghost", "Призрак вокруг цели"),
            Map.entry("Jump Circle", "Круг под ногами при прыжке"),
            Map.entry("China Hat", "Китайская шляпа над головой"),
            Map.entry("Glass Hand", "Стеклянный эффект для руки"),
            Map.entry("Trails", "Оставляет след за игроком"),
            Map.entry("Fullbright", "Максимальная яркость без факелов"),
            Map.entry("FOV", "Настройка угла обзора"),
            Map.entry("Dynamic Island", "Остров с временем и названием"),
            Map.entry("Keybinds", "Список активных биндов на экране"),
            Map.entry("Friends", "Друзья: не бить, подсвечивать (.friend)"),
            Map.entry("Optimization", "Поднимает FPS, не рисует лишнее"));

    private ModuleInfo() {}

    static String desc(Module m) {
        String d = DESC.get(m.getName());
        if (d != null) return d;
        return m.isImplemented() ? "" : "В разработке";
    }
}
