package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/**
 * Ghost Target ESP: glowing orbs (textures/gui/ghost.png) fly around the nearest target on a
 * wavy orbit, each dragging a fading tail. Drawn as a screen overlay via ScreenProjector.
 */
public class TargetEspGhostModule extends Module {
    private static final Identifier TEXTURE = Identifier.of("deathclientdlc", "textures/gui/ghost.png");
    private static final int TEX = 256;

    public final NumberSetting range = add(new NumberSetting("Range", 8, 3, 20, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final NumberSetting orbs = add(new NumberSetting("Orbs", 3, 1, 8, 1));
    public final NumberSetting tail = add(new NumberSetting("Tail", 14, 1, 30, 1));
    public final NumberSetting size = add(new NumberSetting("Size", 1.0, 0.4, 2.5, 0.1));
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.3, 3.0, 0.1));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));

    private final ScreenProjector proj = new ScreenProjector();
    private LivingEntity target;

    public TargetEspGhostModule() { super("Target ESP Ghost", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        LivingEntity best = null;
        double bestDist = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            double d = p.distanceTo(le);
            if (d <= bestDist) { bestDist = d; best = le; }
        }
        target = best;
    }

    @Override
    protected void onDisable() { target = null; }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TargetEspGhostModule m = ModuleManager.get(TargetEspGhostModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        LivingEntity t = m.target;
        if (t == null || !t.isAlive()) return;
        m.draw(ctx, c, t, tickCounter.getTickProgress(false));
    }

    /** One glow sprite to draw: screen position, half-size, alpha and depth for sorting. */
    private record Dot(double x, double y, int half, int alpha, double depth) {}

    private void draw(DrawContext ctx, MinecraftClient c, LivingEntity t, float delta) {
        proj.begin(c, delta);
        Vec3d center = t.getLerpedPos(delta).add(0, t.getHeight() * 0.5, 0);
        double orbit = t.getWidth() * 0.9 + 0.25;
        double half = t.getHeight() * 0.5;
        double now = System.nanoTime() / 1.0e9 * speed.get();
        int n = (int) orbs.get(), len = (int) tail.get();
        int rgb = (themeColor.get() ? Theme.current().accent() : 0xFFFFFF) & 0xFFFFFF;

        List<Dot> dots = new ArrayList<>(n * len);
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < len; k++) {
                double ts = now * 2.4 - k * 0.045;      // tail = the same orbit a moment earlier
                double a = ts + i * (2 * Math.PI / n);
                double y = Math.sin(ts * 1.3 + i * 2.1) * half * 0.9;
                Vec3d w = center.add(Math.cos(a) * orbit, y, Math.sin(a) * orbit);
                if (!proj.project(w)) continue;

                double fade = 1.0 - (double) k / len;    // 1 at the head, 0 at the end of the tail
                double world = (0.16 + 0.22 * fade) * size.get();
                double px = world / (proj.out[2] * proj.tan) * (proj.screenHeight() / 2.0);
                int h = (int) Math.round(Math.max(3, Math.min(px, 60)) );
                int alpha = (int) Math.round(255 * Math.pow(fade, 1.4));
                if (alpha < 4) continue;
                dots.add(new Dot(proj.out[0], proj.out[1], h, alpha, proj.out[2]));
            }
        }

        dots.sort((a, b) -> Double.compare(b.depth(), a.depth())); // far first
        for (Dot d : dots) {
            int color = (d.alpha() << 24) | rgb;
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE,
                    (int) Math.round(d.x()) - d.half(), (int) Math.round(d.y()) - d.half(), 0f, 0f,
                    d.half() * 2, d.half() * 2, TEX, TEX, TEX, TEX, color);
        }
    }
}
