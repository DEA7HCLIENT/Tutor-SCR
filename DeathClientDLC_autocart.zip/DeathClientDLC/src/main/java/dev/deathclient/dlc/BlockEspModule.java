package dev.deathclient.dlc;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/**
 * Block ESP: boxes around chosen blocks (ores, chests, spawners...) visible through walls.
 * Drawn as a screen overlay by projecting each block to the screen (same technique as the Target ESP
 * modules), so it needs no world-render hook. The world is rescanned every few ticks.
 */
public class BlockEspModule extends Module {
    private record Group(BoolSetting setting, Block[] blocks, int color) {}

    public final NumberSetting range = add(new NumberSetting("Range", 16, 4, 32, 2));
    public final NumberSetting maxBoxes = add(new NumberSetting("Max boxes", 200, 20, 600, 20));
    public final BoolSetting fill = add(new BoolSetting("Fill", true));

    private final List<Group> groups = new ArrayList<>();

    private record Hit(BlockPos pos, int color) {}
    private volatile List<Hit> hits = List.of();
    private int ticks;

    public BlockEspModule() {
        super("Block ESP", Category.RENDER);
        group("Diamond", true, 0x33E6FF, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE);
        group("Emerald", true, 0x2EE05A, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
        group("Gold", true, 0xFFD42A, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE);
        group("Iron", false, 0xD8B59A, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
        group("Coal", false, 0x777777, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE);
        group("Redstone", false, 0xFF3030, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
        group("Lapis", false, 0x3050FF, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE);
        group("Copper", false, 0xE0803A, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE);
        group("Ancient Debris", true, 0xA0522D, Blocks.ANCIENT_DEBRIS);
        group("Quartz", false, 0xEEEEEE, Blocks.NETHER_QUARTZ_ORE);
        group("Spawner", true, 0xB040FF, Blocks.SPAWNER);
        group("Chests", true, 0xFFA020, Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL);
        group("Ender Chest", false, 0xA050FF, Blocks.ENDER_CHEST);
    }

    private void group(String name, boolean on, int color, Block... blocks) {
        groups.add(new Group(add(new BoolSetting(name, on)), blocks, color));
    }

    @Override
    protected void onEnable() { ticks = 0; hits = List.of(); }

    @Override
    protected void onDisable() { hits = List.of(); }

    @Override
    public void onTick(MinecraftClient c) {
        if (ticks++ % 10 != 0) return;
        scan(c);
    }

    private void scan(MinecraftClient c) {
        var w = c.world;
        BlockPos center = c.player.getBlockPos();
        int r = (int) range.get();
        int bottom = w.getBottomY(), top = bottom + w.getHeight() - 1;
        int y0 = Math.max(bottom, center.getY() - r), y1 = Math.min(top, center.getY() + r);
        int cap = (int) maxBoxes.get();

        List<Group> active = new ArrayList<>();
        for (Group g : groups) if (g.setting().get()) active.add(g);
        if (active.isEmpty()) { hits = List.of(); return; }

        List<Hit> found = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = center.getX() - r; x <= center.getX() + r; x++) {
            for (int z = center.getZ() - r; z <= center.getZ() + r; z++) {
                for (int y = y0; y <= y1; y++) {
                    m.set(x, y, z);
                    var state = w.getBlockState(m);
                    if (state.isAir()) continue;
                    for (Group g : active) {
                        boolean match = false;
                        for (Block b : g.blocks()) if (state.isOf(b)) { match = true; break; }
                        if (match) { found.add(new Hit(m.toImmutable(), g.color())); break; }
                    }
                }
            }
        }
        // Keep the nearest ones if there are too many.
        if (found.size() > cap) {
            found.sort((a, b) -> Double.compare(center.getSquaredDistance(a.pos()), center.getSquaredDistance(b.pos())));
            found = new ArrayList<>(found.subList(0, cap));
        }
        hits = found;
    }

    // ---- HUD overlay ----

    private static final ScreenProjector PROJ = new ScreenProjector();
    private static final int[][] CORNERS = {
            {0, 0, 0}, {1, 0, 0}, {0, 1, 0}, {1, 1, 0}, {0, 0, 1}, {1, 0, 1}, {0, 1, 1}, {1, 1, 1}};

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        FreecamModule.frame();   // keep the freecam rotation in sync every frame (cheap no-op otherwise)
        BlockEspModule m = ModuleManager.get(BlockEspModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        List<Hit> list = m.hits;
        if (list.isEmpty()) return;

        PROJ.begin(c, tickCounter.getTickProgress(false));
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        for (Hit h : list) {
            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            boolean ok = true;
            for (int[] k : CORNERS) {
                if (!PROJ.project(new Vec3d(h.pos().getX() + k[0], h.pos().getY() + k[1], h.pos().getZ() + k[2]))) { ok = false; break; }
                minX = Math.min(minX, PROJ.out[0]); maxX = Math.max(maxX, PROJ.out[0]);
                minY = Math.min(minY, PROJ.out[1]); maxY = Math.max(maxY, PROJ.out[1]);
            }
            if (!ok) continue;
            int x0 = (int) Math.floor(minX), y0 = (int) Math.floor(minY);
            int x1 = (int) Math.ceil(maxX), y1 = (int) Math.ceil(maxY);
            if (x1 < 0 || y1 < 0 || x0 > sw || y0 > sh) continue;
            if (x1 - x0 > sw || y1 - y0 > sh) continue;
            int col = 0xFF000000 | h.color();
            if (m.fill.get()) ctx.fill(x0, y0, x1, y1, 0x30000000 | h.color());
            ctx.fill(x0, y0, x1, y0 + 1, col);          // top
            ctx.fill(x0, y1 - 1, x1, y1, col);          // bottom
            ctx.fill(x0, y0, x0 + 1, y1, col);          // left
            ctx.fill(x1 - 1, y0, x1, y1, col);          // right
        }
    }
}
