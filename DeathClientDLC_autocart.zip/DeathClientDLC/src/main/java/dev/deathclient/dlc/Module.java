package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;
    /** GUI state: settings list unfolded. */
    public boolean expanded;
    /** GLFW key code bound to toggle this module, or -1. */
    private int key = -1;
    /** Last polled state of the bound key (edge detection). */
    boolean keyDown;

    protected Module(String name, Category category) {
        this(name, category, false);
    }

    /** defaultEnabled starts the module on without running onEnable() (used for always-on HUD modules). */
    protected Module(String name, Category category, boolean defaultEnabled) {
        this.name = name;
        this.category = category;
        this.enabled = defaultEnabled;
    }

    protected <T extends Setting> T add(T setting) { settings.add(setting); return setting; }

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public List<Setting> getSettings() { return settings; }
    public boolean isEnabled() { return enabled; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }

    /** False for menu entries whose logic is not written yet (shown with a WIP tag). */
    public boolean isImplemented() { return true; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    /** Called every client tick while enabled and a world is loaded. */
    public void onTick(MinecraftClient client) {}
}
