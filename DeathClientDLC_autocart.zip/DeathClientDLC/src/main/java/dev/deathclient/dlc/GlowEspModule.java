package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Glow ESP through vanilla's outline renderer (see mixin.EntityMixin). No custom drawing code: the game
 * renders the outline itself, through walls, in the color returned by colorFor().
 */
public class GlowEspModule extends Module {
    // ---- configuration: colors are 0xRRGGBB ----
    static final int COLOR_PLAYER  = 0xFF4040;
    static final int COLOR_HOSTILE = 0xFF9933;
    static final int COLOR_PASSIVE = 0x55FF55;
    static final int COLOR_ITEM    = 0x55AAFF;
    static final int COLOR_FRIEND  = 0x55FFFF;

    private static volatile GlowEspModule instance;

    public final NumberSetting range = add(new NumberSetting("Range", 32, 8, 64, 4));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
    public final BoolSetting passive = add(new BoolSetting("Passive", false));
    public final BoolSetting items = add(new BoolSetting("Items", false));

    public GlowEspModule() {
        super("Glow ESP", Category.RENDER);
        instance = this;
    }

    /** Outline color for this entity, or -1 if it must not glow. Called by the mixin every frame. */
    public static int colorFor(Entity e) {
        GlowEspModule m = instance;
        if (m == null || !m.isEnabled()) return -1;

        MinecraftClient c = MinecraftClient.getInstance();
        // The integrated server shares the Entity class; only the render thread may touch the client world.
        if (c == null || !c.isOnThread()) return -1;
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || e == p) return -1;
        if (c.world.getEntityById(e.getId()) != e) return -1;   // client-side copies only

        if (e instanceof LivingEntity le && (!le.isAlive() || le.isSpectator())) return -1;
        if (p.distanceTo(e) > m.range.get()) return -1;

        if (e instanceof PlayerEntity) {
            FriendsModule fm = ModuleManager.get(FriendsModule.class);
            if (fm != null && fm.highlight.get() && Friends.isFriend(e)) return COLOR_FRIEND;
            return m.players.get() ? COLOR_PLAYER : -1;
        }
        if (e instanceof HostileEntity) return m.hostile.get() ? COLOR_HOSTILE : -1;
        if (e instanceof LivingEntity) return m.passive.get() ? COLOR_PASSIVE : -1;
        if (e instanceof ItemEntity) return m.items.get() ? COLOR_ITEM : -1;
        return -1;
    }
}
