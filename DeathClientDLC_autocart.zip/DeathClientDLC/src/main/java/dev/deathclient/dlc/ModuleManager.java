package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = List.of(
            // Combat
            new KillAuraModule(),
            new TpAuraModule(),
            new CrystalAuraModule(),
            new AnchorAuraModule(),
            new Autocart(),
            new CrystalOptimizationModule(),
            // Movement
            new SpeedModule(),
            new StrafeModule(),
            new TargetStrafeModule(),
            new FlyModule("Fly", false),
            new NoClipModule(),
            new FlyModule("NoClip Fly", true),
            new SpinModule(),
            // Render
            new PendingModule("ESP", Category.RENDER),
            new GlowEspModule(),
            new BlockEspModule(),
            new FreecamModule(),
            new PendingModule("Chams", Category.RENDER),
            new PendingModule("No Render", Category.RENDER),
            new PendingModule("View Model", Category.RENDER),
            new SwingAnimationModule(),
            new VisualSpinModule(),
            // Visuals
            new PendingModule("Tracers", Category.VISUALS),
            new PendingModule("Line Trails", Category.VISUALS),
            new TargetEspModule(),
            new TargetEspImageModule(),
            new TargetEspGhostModule(),
            new JumpCircleModule(),
            new ChinaHatModule(),
            new PendingModule("Glass Hand", Category.VISUALS),
            new TrailsModule(),
            new FullbrightModule(),
            new FovModule(),
            // Misc
            new DynamicIslandModule(),
            new KeybindsModule(),
            new FriendsModule(),
            new OptimizationModule());

    private ModuleManager() {}

    public static List<Module> all() { return MODULES; }

    public static List<Module> of(Category c) {
        return MODULES.stream().filter(m -> m.getCategory() == c).toList();
    }

    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return type.cast(m);
        return null;
    }

    public static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        Config.applyPendingEnabled();
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(client);
    }
}
