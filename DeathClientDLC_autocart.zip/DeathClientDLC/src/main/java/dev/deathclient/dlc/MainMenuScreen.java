package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Replacement title screen. The pencil (top left) switches to edit mode: drag buttons, drop an image to set the background. */
public class MainMenuScreen extends Screen {
    private static final int BW = 150, BH = 24, GAP = 6;
    private static final int NORMAL = 0xE0303030, WHITE = 0xFFFFFFFF;
    private static final int PX = 6, PY = 6, PS = 20;

    private record Item(String label, Runnable action) {}

    private final List<Item> items = new ArrayList<>();
    private boolean editing;
    private int dragIndex = -1, grabDX, grabDY;
    private String status = "";
    private long statusUntil;

    public MainMenuScreen() { super(Text.literal("DeathClientDLC")); }

    @Override
    protected void init() {
        MenuCustom.ensureLoaded();
        items.clear();
        items.add(new Item("Singleplayer", () -> client.setScreen(new SelectWorldScreen(this))));
        items.add(new Item("Multiplayer", () -> client.setScreen(new MultiplayerScreen(this))));
        items.add(new Item("Settings", () -> client.setScreen(new OptionsScreen(this, client.options))));
        items.add(new Item("Cheat Menu", () -> client.setScreen(new ClickGuiScreen())));
        items.add(new Item("Accounts", () -> client.setScreen(new AccountsScreen(this))));
        items.add(new Item("Quit", () -> client.scheduleStop()));
    }

    private int baseX() { return width - BW - (int) (width * 0.24); }

    private int baseY(int index) {
        int total = items.size() * BH + (items.size() - 1) * GAP;
        int y0 = Math.max(Ui.TITLE_TOP + Ui.titleHeight() + 12, (height - total) / 2 + 15);
        return y0 + index * (BH + GAP);
    }

    private int bx(int i) { return clamp(baseX() + MenuCustom.offX[i], 0, Math.max(0, width - BW)); }

    private int by(int i) { return clamp(baseY(i) + MenuCustom.offY[i], 0, Math.max(0, height - BH)); }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int barW() { return Math.min(120, (width - 36) / 3); }

    private int barX(int k) {
        int bw = barW();
        int total = bw * 3 + 12;
        return (width - total) / 2 + k * (bw + 6);
    }

    private int barY() { return height - 30; }

    private void setStatus(String s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 4000;
    }

    private static void outline(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (MenuCustom.hasBackground()) MenuCustom.drawBackground(ctx, width, height);
        else Ui.drawBackground(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        Ui.drawTitle(ctx, width);

        for (int i = 0; i < items.size(); i++) {
            int x = bx(i), y = by(i);
            String label = items.get(i).label();
            boolean hover = in(mx, my, x, y, BW, BH);
            int color = (editing ? dragIndex == i : hover) ? Theme.current().accent() : NORMAL;
            ClickGuiScreen.rect(ctx, x, y, BW, BH, color, true, true);
            if (editing) outline(ctx, x - 1, y - 1, BW + 2, BH + 2, WHITE);
            ctx.drawTextWithShadow(textRenderer, label, x + (BW - textRenderer.getWidth(label)) / 2, y + (BH - 8) / 2, WHITE);
        }

        ctx.drawTextWithShadow(textRenderer, "Аккаунт: " + Accounts.currentName(), 6, height - 12, 0xFFB8B8C4);

        // pencil
        boolean pHover = in(mx, my, PX, PY, PS, PS);
        ClickGuiScreen.rect(ctx, PX, PY, PS, PS, (editing || pHover) ? Theme.current().accent() : NORMAL, true, true);
        for (int k = 0; k < 10; k++) {
            ctx.fill(PX + 4 + k, PY + 15 - k, PX + 7 + k, PY + 18 - k, WHITE);
        }
        ctx.fill(PX + 3, PY + 16, PX + 5, PY + 18, 0xFFFFD866);

        if (editing) {
            String hint = "Тяни кнопки мышью. Перетащи картинку в окно игры - она станет фоном.";
            ctx.drawCenteredTextWithShadow(textRenderer, hint, width / 2, barY() - 14, WHITE);
            if (System.currentTimeMillis() < statusUntil) {
                ctx.drawCenteredTextWithShadow(textRenderer, status, width / 2, barY() - 26, 0xFFFFD866);
            }
            String[] labels = {"Сбросить фон", "Сбросить кнопки", "Готово"};
            for (int k = 0; k < 3; k++) {
                int x = barX(k), y = barY(), bw = barW();
                ClickGuiScreen.rect(ctx, x, y, bw, 22, in(mx, my, x, y, bw, 22) ? Theme.current().accent() : NORMAL, true, true);
                ctx.drawTextWithShadow(textRenderer, labels[k], x + (bw - textRenderer.getWidth(labels[k])) / 2, y + 7, WHITE);
            }
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            double mx = click.x(), my = click.y();
            if (in(mx, my, PX, PY, PS, PS)) {
                editing = !editing;
                dragIndex = -1;
                return true;
            }
            if (editing) {
                for (int k = 0; k < 3; k++) {
                    if (in(mx, my, barX(k), barY(), barW(), 22)) {
                        if (k == 0) { MenuCustom.resetBackground(); setStatus("Фон сброшен"); }
                        else if (k == 1) { MenuCustom.resetButtons(); setStatus("Кнопки сброшены"); }
                        else { editing = false; }
                        return true;
                    }
                }
                for (int i = items.size() - 1; i >= 0; i--) {
                    if (in(mx, my, bx(i), by(i), BW, BH)) {
                        dragIndex = i;
                        grabDX = (int) mx - bx(i);
                        grabDY = (int) my - by(i);
                        return true;
                    }
                }
                return true;
            }
            for (int i = 0; i < items.size(); i++) {
                if (in(mx, my, bx(i), by(i), BW, BH)) {
                    items.get(i).action().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (editing && dragIndex >= 0 && click.button() == 0) {
            int nx = clamp((int) click.x() - grabDX, 0, Math.max(0, width - BW));
            int ny = clamp((int) click.y() - grabDY, 0, Math.max(0, height - BH));
            MenuCustom.offX[dragIndex] = nx - baseX();
            MenuCustom.offY[dragIndex] = ny - baseY(dragIndex);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragIndex >= 0) {
            dragIndex = -1;
            MenuCustom.save();
            return true;
        }
        return super.mouseReleased(click);
    }

    // Dropping an image file onto the game window (the method name differs between mappings, so both are defined).
    public void filesDragged(List<Path> paths) { handleDrop(paths); }

    public void onFilesDropped(List<Path> paths) { handleDrop(paths); }

    private void handleDrop(List<Path> paths) {
        if (!editing || paths == null || paths.isEmpty()) return;
        try {
            MenuCustom.setBackground(paths.get(0));
            setStatus("Фон установлен");
        } catch (Exception e) {
            setStatus("Не удалось загрузить картинку (нужен png или jpg)");
        }
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
