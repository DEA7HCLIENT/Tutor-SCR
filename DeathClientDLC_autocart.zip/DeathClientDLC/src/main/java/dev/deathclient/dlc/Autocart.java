package dev.deathclient.dlc;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * When you shoot a bow, places a rail next to / under the player you aim at (or on the block you aim at)
 * and a TNT minecart on that rail. Needs a rail and a TNT minecart in the hotbar. The previous slot is restored.
 * Tip: a flame arrow ignites the TNT minecart.
 */
public class Autocart extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 4.5, 2, 6, 0.5));
    public final NumberSetting delay = add(new NumberSetting("Delay", 1, 1, 5, 1));
    public final NumberSetting minDist = add(new NumberSetting("Min self dist", 3, 0, 6, 0.5));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", false));

    private enum Step { IDLE, RAIL, CART }

    private Step step = Step.IDLE;
    private BlockPos railPos;
    private int savedSlot;
    private int wait;
    private int timeout;
    private boolean wasDrawing;
    private int drawTicks;

    public Autocart() { super("AutoCart", Category.COMBAT); }

    @Override
    protected void onDisable() {
        step = Step.IDLE;
        wasDrawing = false;
        drawTicks = 0;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;

        if (step != Step.IDLE) {
            if (wait > 0) { wait--; return; }
            if (step == Step.RAIL) placeRail(c, p);
            else placeCart(c, p);
            return;
        }

        boolean drawing = p.isUsingItem() && p.getActiveItem().isOf(Items.BOW);
        if (drawing) drawTicks++;
        boolean holdsBow = p.getMainHandStack().isOf(Items.BOW) || p.getOffHandStack().isOf(Items.BOW);
        boolean shot = wasDrawing && !drawing && drawTicks >= 3 && holdsBow;
        wasDrawing = drawing;
        if (!drawing) drawTicks = 0;
        if (shot) start(c, p);
    }

    private void start(MinecraftClient c, ClientPlayerEntity p) {
        if (c.interactionManager == null) return;
        if (findRail(p) < 0 || Util.findHotbar(p, Items.TNT_MINECART) < 0) return;
        BlockPos pos = resolve(c, p);
        if (pos == null) return;
        railPos = pos;
        savedSlot = p.getInventory().getSelectedSlot();
        timeout = 6;
        wait = 0;
        step = c.world.getBlockState(pos).isIn(BlockTags.RAILS) ? Step.CART : Step.RAIL;
    }

    private void placeRail(MinecraftClient c, ClientPlayerEntity p) {
        int slot = findRail(p);
        if (slot < 0) { finish(p); return; }
        p.getInventory().setSelectedSlot(slot);
        place(c, p, railPos.down(), Direction.UP);
        step = Step.CART;
        wait = (int) delay.get();
    }

    private void placeCart(MinecraftClient c, ClientPlayerEntity p) {
        if (!c.world.getBlockState(railPos).isIn(BlockTags.RAILS)) {
            if (--timeout <= 0) finish(p);       // rail never appeared
            return;
        }
        int slot = Util.findHotbar(p, Items.TNT_MINECART);
        if (slot >= 0) {
            p.getInventory().setSelectedSlot(slot);
            place(c, p, railPos, Direction.UP);
        }
        finish(p);
    }

    private void finish(ClientPlayerEntity p) {
        p.getInventory().setSelectedSlot(savedSlot);
        step = Step.IDLE;
        wasDrawing = false;
        drawTicks = 0;
    }

    private static int findRail(ClientPlayerEntity p) {
        int s = Util.findHotbar(p, Items.RAIL);
        if (s < 0) s = Util.findHotbar(p, Items.POWERED_RAIL);
        if (s < 0) s = Util.findHotbar(p, Items.DETECTOR_RAIL);
        if (s < 0) s = Util.findHotbar(p, Items.ACTIVATOR_RAIL);
        return s;
    }

    /** Where the rail goes: around the aimed (or nearest) player, else on the aimed block. */
    private BlockPos resolve(MinecraftClient c, ClientPlayerEntity p) {
        double reach = range.get();
        HitResult hr = c.crosshairTarget;

        PlayerEntity target = null;
        if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof PlayerEntity pe && !Friends.skip(pe)) target = pe;
        if (target == null) target = Util.nearestPlayer(c, reach + 2);

        if (target != null) {
            BlockPos feet = target.getBlockPos();
            BlockPos[] cands = {feet, feet.north(), feet.south(), feet.east(), feet.west()};
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            for (BlockPos b : cands) {
                if (!usable(c, p, b, reach)) continue;
                double d = Vec3d.ofCenter(b).distanceTo(Util.pos(target));
                if (d < bestD) { bestD = d; best = b; }
            }
            if (best != null) return best;
        }

        if (!playersOnly.get() && hr instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            BlockPos b = bhr.getBlockPos().offset(bhr.getSide());
            if (usable(c, p, b, reach)) return b;
        }
        return null;
    }

    /** A rail already there, or an empty block standing on a solid one - within reach and not too close to you. */
    private boolean usable(MinecraftClient c, ClientPlayerEntity p, BlockPos b, double reach) {
        if (p.getEyePos().distanceTo(Vec3d.ofCenter(b)) > reach) return false;
        if (Util.pos(p).distanceTo(Vec3d.ofCenter(b)) < minDist.get()) return false;
        BlockState st = c.world.getBlockState(b);
        if (st.isIn(BlockTags.RAILS)) return true;
        BlockPos below = b.down();
        return st.isAir() && c.world.getBlockState(below).isSolidBlock(c.world, below);
    }

    private void place(MinecraftClient c, ClientPlayerEntity p, BlockPos on, Direction side) {
        Vec3d hit = Vec3d.ofCenter(on).add(Vec3d.of(side.getVector()).multiply(0.5));
        c.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, side, on, false));
        p.swingHand(Hand.MAIN_HAND);
    }
}
