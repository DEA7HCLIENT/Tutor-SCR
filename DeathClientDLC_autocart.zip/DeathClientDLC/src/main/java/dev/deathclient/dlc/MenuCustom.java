package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.function.Supplier;

/** Main-menu customisation: own background image and moved buttons (saved between launches). */
final class MenuCustom {
    static final int SLOTS = 8;
    static final int[] offX = new int[SLOTS];
    static final int[] offY = new int[SLOTS];

    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc");
    private static final Path BG = DIR.resolve("menu_bg.png");
    private static final Path FILE = DIR.resolve("menu.properties");
    private static final Identifier BG_ID = Identifier.of("deathclientdlc", "custom_menu_bg");

    private static boolean loaded, hasBg;
    private static int bgW = 1, bgH = 1;

    private MenuCustom() {}

    static boolean hasBackground() { return hasBg; }

    /** Call on the render thread (the texture is created here). */
    static void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        loadProps();
        if (Files.exists(BG)) {
            try { show(Files.readAllBytes(BG)); } catch (Exception e) { hasBg = false; }
        }
    }

    static void setBackground(Path src) throws Exception {
        byte[] png = toPng(Files.readAllBytes(src));
        Files.createDirectories(DIR);
        Files.write(BG, png);
        show(png);
    }

    static void resetBackground() {
        hasBg = false;
        try { Files.deleteIfExists(BG); } catch (IOException ignored) {}
    }

    static void resetButtons() {
        for (int i = 0; i < SLOTS; i++) { offX[i] = 0; offY[i] = 0; }
        save();
    }

    static void save() {
        Properties p = new Properties();
        for (int i = 0; i < SLOTS; i++) {
            p.setProperty("x" + i, Integer.toString(offX[i]));
            p.setProperty("y" + i, Integer.toString(offY[i]));
        }
        try {
            Files.createDirectories(DIR);
            try (var out = Files.newOutputStream(FILE)) { p.store(out, "DeathClientDLC main menu layout"); }
        } catch (IOException ignored) {}
    }

    private static void loadProps() {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (var in = Files.newInputStream(FILE)) { p.load(in); } catch (IOException e) { return; }
        for (int i = 0; i < SLOTS; i++) {
            offX[i] = num(p.getProperty("x" + i));
            offY[i] = num(p.getProperty("y" + i));
        }
    }

    private static int num(String s) {
        if (s == null) return 0;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return 0; }
    }

    private static byte[] toPng(byte[] raw) throws IOException {
        boolean isPng = raw.length > 8 && (raw[0] & 0xFF) == 0x89 && raw[1] == 'P' && raw[2] == 'N' && raw[3] == 'G';
        if (isPng) return raw;
        BufferedImage bi = ImageIO.read(new ByteArrayInputStream(raw));
        if (bi == null) throw new IOException("unsupported image");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(bi, "png", out);
        return out.toByteArray();
    }

    private static void show(byte[] png) throws Exception {
        NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
        int w = img.getWidth(), h = img.getHeight();
        AbstractTexture tex = makeTexture(img);
        MinecraftClient.getInstance().getTextureManager().registerTexture(BG_ID, tex);
        bgW = w;
        bgH = h;
        hasBg = true;
    }

    /** The texture constructor changed between versions, so pick whichever one exists. */
    private static AbstractTexture makeTexture(NativeImage img) throws Exception {
        Supplier<String> name = () -> "deathclientdlc_menu_bg";
        AbstractTexture tex = null;
        for (Constructor<?> c : NativeImageBackedTexture.class.getConstructors()) {
            Class<?>[] p = c.getParameterTypes();
            if (p.length == 1 && p[0] == NativeImage.class) {
                tex = (AbstractTexture) c.newInstance(img);
                break;
            }
            if (p.length == 2 && p[1] == NativeImage.class) {
                if (p[0] == String.class) { tex = (AbstractTexture) c.newInstance("deathclientdlc_menu_bg", img); break; }
                if (p[0] == Supplier.class) { tex = (AbstractTexture) c.newInstance(name, img); break; }
            }
        }
        if (tex == null) throw new IllegalStateException("no texture constructor");
        try { tex.getClass().getMethod("upload").invoke(tex); } catch (Exception ignored) {}
        return tex;
    }

    /** Cover-fit, centred. */
    static void drawBackground(DrawContext ctx, int width, int height) {
        double scale = Math.max((double) width / bgW, (double) height / bgH);
        int rw = (int) Math.min(bgW, Math.ceil(width / scale));
        int rh = (int) Math.min(bgH, Math.ceil(height / scale));
        float u = (bgW - rw) / 2f;
        float v = (bgH - rh) / 2f;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BG_ID, 0, 0, u, v, width, height, rw, rh, bgW, bgH);
    }
}
