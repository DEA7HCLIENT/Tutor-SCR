package dev.deathclient.dlc;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Custom (non-Minecraft) UI font: assets/deathclientdlc/font/ui.json -> ui.ttf (Liberation Sans, OFL).
 * To use another font, replace ui.ttf with any TTF that has the glyphs you need (Latin + Cyrillic).
 * All font-specific API usage is kept in this one class.
 */
final class Fonts {
    private static final Identifier UI = Identifier.of("deathclientdlc", "ui");
    private static final Style STYLE = Style.EMPTY.withFont(new StyleSpriteSource.Font(UI));

    private Fonts() {}

    static Text text(String s) { return Text.literal(s).setStyle(STYLE); }

    static int width(TextRenderer tr, String s) { return tr.getWidth(text(s)); }

    static void draw(DrawContext ctx, TextRenderer tr, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(tr, text(s), x, y, color);
    }
}
